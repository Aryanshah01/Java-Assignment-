import java.util.Scanner;

public class Test {
	
	public static int add(int ...a) { 
		int sum=0;
		for(int i=0;i<a.length;i++) {
			sum=sum+a[i];
		}
		return sum;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(add(10,20,30,40));
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no of numbers to be added");
		int n = sc.nextInt();
		int[] numbers = new int[n];
		System.out.println("Enter the numbers");
		for(int i=0; i<n; i++) {
			numbers[i] = sc.nextInt();
		}
		System.out.println(add(numbers));
		}

}
