package in.mindcraft;

public class Marketing extends Employee{
	
	private int km;
	private int tour_all;
	private int tel_all;
	private int gross_sal;
	private int net_sal;
	private int all;
	private int PF;
	
	public Marketing(){
		km=0;
		tour_all=0;
		tel_all=0;
		gross_sal=0;
		net_sal=0;
		all =0;
		PF = 0;
	}

	public Marketing(int km, int emp_id, String name, int b_sal) {
		super(emp_id,name,b_sal);
		this.km = km;
		tour_all = km*5;
		tel_all = 2000;
		all = tour_all+tel_all;
		PF = 125*b_sal/1000;
		gross_sal = b_sal+all;
		net_sal = gross_sal-PF;
	}
	
	public void show() {
		System.out.println("Overall kms: "+km);
		System.out.println("Tour Allowance: "+tour_all);
		System.out.println("Telephone Allowance: "+tel_all);
		System.out.println("Overall Allowances: "+all);
		System.out.println("PF: "+PF);
		System.out.println("Gross Salary: "+gross_sal);
		System.out.println("Net Salary: "+net_sal);
	}
	
}
