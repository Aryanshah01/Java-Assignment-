package in.mindcraft;

public class Manager extends Employee{
	
	private int petrol_all;
	private int food_all;
	private int other_all;
	private int gross_sal;
	private int net_sal;
	private int all;
	private int PF;

	public Manager() {
		petrol_all=0;
		food_all=0;
		other_all=0;
		gross_sal=0;
		net_sal=0;
		all =0;
		PF = 0;
	}

	public Manager(int empid, String name, int b_sal) {
		super(empid,name,b_sal);
		
		petrol_all = 8*b_sal/100;
		food_all = 12*b_sal/100;
		other_all = 4*b_sal/100;
		all = petrol_all+food_all+other_all;
		gross_sal = b_sal + all;
		PF = 125*b_sal/1000;
		net_sal = gross_sal - PF;
	}
	
	public void show() {
		super.show();
		System.out.println("Petrol Allowance:"+petrol_all);
		System.out.println("Food Allowance: "+food_all);
		System.out.println("Other Allowance: "+other_all);
		System.out.println("Overall Allowances: "+all);
		System.out.println("PF: "+PF);
		System.out.println("Gross Salary: "+gross_sal);
		System.out.println("Net Salary: "+net_sal);
		
	}
	
}
