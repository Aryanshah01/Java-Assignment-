// Collection Framework
import java.util.LinkedHashSet;
import java.util.Set;

public class Linked_HashSet {

	public static void main(String[] args) {
		
		// Linked_HashSet Initialization 
		Set<String> l1 = new LinkedHashSet<>();
		
		// Adding Elements 
		l1.add("Aryan");
		l1.add("Anay");
		l1.add("Amit");
		l1.add("Amit"); // Duplicate entry will be ignored 
		
		System.out.println(l1); // Insertion is Preserved 
		
		// Removing Elements 
		l1.remove("Aryan");
		System.out.println(l1);
		
		// Is present
		boolean isp = l1.contains("Aryan");
		System.out.println(isp);
		
		// Size of the LinkedHashSet
		System.out.println(l1.size());
		
		// Elements in column 
		for(String name:l1) {
			System.out.println(name);
		}
	}

}
