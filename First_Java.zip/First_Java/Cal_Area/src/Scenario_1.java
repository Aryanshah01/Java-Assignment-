class shape{

	public void area(int l, int w) {
		int a = l*w;
		System.out.println("Area of rectangle " + a);
	}
	
	public void area(int l) {
		int a = l*l;
		System.out.println("Area of square " + a);
	}
	
	public void area(float r, float pi) {
		float a = pi*r*r;
		System.out.println("Area of circle " + a);
	}
}
	
public class Scenario_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		shape s1 = new shape();
		s1.area(10);
		
		shape r1 = new shape();
		r1.area(10, 5);
		
		shape c1 = new shape();
		c1.area(5, 3.14f);
		
	}

}
