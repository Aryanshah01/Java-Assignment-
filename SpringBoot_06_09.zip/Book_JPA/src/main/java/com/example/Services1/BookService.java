package com.example.Services1;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Dao.BookRepository;
import com.example.Entity1.Book;

@Service
public class BookService {

		@Autowired
	    private BookRepository bookRepository;

		public BookService(BookRepository bookRepository) {
			super();
			this.bookRepository = bookRepository;
		}

	    public List<Book> getAllBook(){
	    	
	    	List<Book> list=(List<Book>)this.bookRepository.findAll();
	    	return list;
	    }
	    
	    public Book getBookById(int bid) {
	    	Book book=null;
	    	try {
	    		book=this.bookRepository.findById(bid);	
	    	}
	    	catch(Exception e) {
	    		e.printStackTrace();
	    	}
	    	return book;
	    }
	    
	    public Book addBook(Book b) {
	    	Book result=bookRepository.save(b);
	    	return b;
	    }
	    
	    public void deleteBook(int bid) {
	    	bookRepository.deleteById(bid);
	    }
	    	    
	    public void updateBook(Book book,int bId) {
	    	book.setBid(bId);
	    	bookRepository.save(book);
	    	
    }
}

