import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Customer{
	int c_id;
	String name;
	int []cart = new int[10];
	int []bills = new int[10];
	
	public Customer() {
		c_id=101;
		name="Aryan";
	}
	
	
	public Customer(int c_id, String name, int[] cart, int[] bills) {
		super();
		this.c_id = c_id;
		this.name = name;
		this.cart = cart;
		this.bills = bills;
	}
}
	
class C_Login {
	
	int c_id;
	String name;
	
	public void display_customer() {
		System.out.println("Enter Customer ID: ");
		Scanner sc = new Scanner(System.in);
		c_id = sc.nextInt();
		System.out.println("Enter Customer name: ");
		name = sc.next();
	}
}
	
class Admin{
	
	String a_name;
	String a_pass;
	int cust_id;
	String cust_name;
	int pro_id;
	String pro_name;
	int pro_price;
	
	public Admin(){
		a_name="Aryan";
		a_pass="Aryan";
		cust_id = 101;
		cust_name = "Aryan";
		pro_id = 102;
		pro_name = "choco";
		pro_price = 100;
		
	}
	
		public Admin(String a_name, String a_pass, int cust_id, String cust_name, int pro_id, String pro_name, int pro_price) {
		super();
		this.a_name = a_name;
		this.a_pass = a_pass;
		this.cust_id = cust_id;
		this.cust_name = cust_name;
		this.pro_id = pro_id;
		this.pro_name = pro_name;
		this.pro_price = pro_price;
	}

		public void display_admin() {
		System.out.println("Enter admin name: ");
		Scanner sc = new Scanner(System.in);
		a_name = sc.next();
		System.out.println("Enter admin password: ");
		a_pass = sc.next();	
	}
		
		public void display_new_customer() {
			Scanner sc = new Scanner(System.in);
			System.out.println("Add New Customer ID");
			cust_id = sc.nextInt();
			System.out.println("Add Customer Name");
			cust_name = sc.next();
		}
		
		public void display_new_product() {
			Scanner sc = new Scanner(System.in);
			System.out.println("Add Product Name");
			pro_name = sc.next();
			System.out.println("Add Product Price");
			pro_price = sc.nextInt();
		}
	
}

class Product{
	int p_id;
	String name;
	int price;
	
	public Product() {
		p_id=101;
		name="Choco Pie";
	}
	
	public Product(int p_id, String name, int price) {
		super();
		this.p_id = p_id;
		this.name = name;
		this.price = price;
	}
	
	public void display_product() {
		System.out.println("Enter product ID: ");
		Scanner sc = new Scanner(System.in);
		p_id = sc.nextInt();
		System.out.println("Enter Product name: ");
		name = sc.next();
		System.out.println("Enter Product Price: ");
		price = sc.nextInt();
	}

}


public class Test {

	public static void main(String[] args) {

		List<Customer> c1 = new ArrayList<Customer>();
		List<Product> p1 = new ArrayList<Product>();
		Product p = new Product();
		Customer c = new Customer();
		Scanner sc = new Scanner(System.in);
		while(true) {
			int choice;
			System.out.println("1. Customer Login: ");
			System.out.println("2. Admin Login");
			System.out.println("3. Exit");
			choice = sc.nextInt();
			switch(choice) {
			case 1:
				while (true) {
				p.display_product();
				p1.add(p);
				System.out.println("1. Add Products");
				System.out.println("2. Show Product Details");
				System.out.println("3. Exit");
				int v = sc.nextInt();
				switch(v) {
				case 1:
					p.display_product();
					p1.add(p);
					break;
					
				case 2:
					for(int i=0;i<p1.size();i++) {
						System.out.println(p1.get(i).p_id+" "+p1.get(i).name+" "+p1.get(i).price);
					}
					System.out.println();
					break;
					
				case 3:
					break;
					
				}
				break;
				}
				break;
				
			case 2:
					Admin a1 = new Admin();
					a1.display_admin();
					while(true) {
					System.out.println("1. Add New Customer");
					System.out.println("2. Add New Product");
					System.out.println("3. Exit");
					int g = sc.nextInt();
					switch(g) {
					case 1:
						a1.display_new_customer();
						Customer d = new Customer();
						c1.add(d);
						break;
						
					case 2:
						a1.display_new_product();
						p1.add(p);
						
					case 3:
						break;
					}
					break;
				}
					break;
			case 3:
				System.exit(0);
					}
			}
		}
		
	}
