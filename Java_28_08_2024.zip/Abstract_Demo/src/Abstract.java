abstract class Animal{
	 abstract void sound();
}

abstract class People{
	abstract void type();
}


// Two abstract classes cannot be extended 
class Dog extends Animal{
	void sound() {
		System.out.println("Dog barks ...");
	}
}


public class Abstract {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dog d1 = new Dog();
		d1.sound();
	}

}
