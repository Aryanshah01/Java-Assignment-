class Account{
	protected double balance;

	public Account(double balance) {
		super();
		this.balance = balance;
	}
	
	public void deposit(double amount) {
		balance += amount;
	}
	
	public void withdraw(double amount) throws Exception{
		if(amount>balance) {
			throw new Exception("Insufficient Balance");
		}
		else if(amount>15000) {
			throw new Exception("OverLimit");
		}
		else {
			balance -= amount;
		}
	}
}
public class Test {

	public static void main(String[] args) {
		
		Account acc = new Account(30000);
		acc.deposit(10000);
		try {
			acc.withdraw(15000);
			System.out.println(acc.balance);
		}
		catch (Exception e) {
			System.out.println(e);
		}
		
	}

}
