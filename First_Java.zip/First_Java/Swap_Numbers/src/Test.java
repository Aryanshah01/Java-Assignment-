import java.util.Scanner;

class Swap{
	int x,y;
	
	public void Num() {
		System.out.println("Enter the first number: ");
		Scanner sc = new Scanner(System.in);
		x = sc.nextInt();
		System.out.println("Enter the second number: ");
		y = sc.nextInt();
		
		x = x+y;
		y = x-y;
		x = x-y;
		
		System.out.println("The numbers have been swapped: " +x + y);
	}
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Swap fun = new Swap();
		fun.Num();
	}

}
