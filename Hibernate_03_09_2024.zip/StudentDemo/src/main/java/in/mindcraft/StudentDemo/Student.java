package in.mindcraft.StudentDemo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;


@Entity
public class Student {
	
	@Id
	private int sid;
	private String name;
	
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	@ManyToMany
	List<Laptop> list_01 = new ArrayList<Laptop>();

	public List<Laptop> getList_01() {
		return list_01;
	}
	public void setList_01(List<Laptop> list_01) {
		this.list_01 = list_01;
	}
	
}
