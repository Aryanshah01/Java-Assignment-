package in.mindcraft;

public class Employee {

	private int emp_id;
	private String ename;
	private Date dob;
	
	public Employee() {
		emp_id = 101;
		ename = "Aryan";
		dob = new Date();
	}

	public Employee(int eid, String name, int dd, int mm, int yy) {
		this.emp_id = eid;
		this.ename = name;
		dob = new Date(dd,mm,yy);
	}
	
	public void show() {
		System.out.println("empid: "+emp_id);
		System.out.println("ename: "+ename);
		dob.show();
	}
	
}
