import java.util.Scanner;

class ThreadMulti extends Thread{

	int a;

	public ThreadMulti(int a) {
		super();
		this.a = a;
	}
	
	public void run() {
		for(int i=1;i<10;i++) {
			System.out.println(a+"*"+i+":"+a*i);
		}
	}
}

class ThreadAdd extends Thread{
	
	int b;

	public ThreadAdd(int b) {
		super();
		this.b = b;
	}
	
	public void run() {
		for(int i=b; i<=b+10; i++) {
			System.out.println("Add:"+i);
		}
	}
}


public class Thread_Multiplication_Demo {

	public static void main(String[] args) {
		
		int a,b;
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter the value for Addition: ");
		b = sc.nextInt();
		System.out.println("Please enter the value for multiplication: ");
		a = sc.nextInt();
		
		ThreadMulti t1 = new ThreadMulti(a);
		t1.start();
		ThreadAdd t2 = new ThreadAdd(b);
		t2.start();
	}

}
