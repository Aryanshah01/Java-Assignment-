package in.mindcraft.LaptopDemo;

import java.util.Scanner;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Laptop {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int lid;
	private String name;
	private double cost;
	
	public Laptop() {
		lid = 101;
		name = "Apple";
		cost = 100000;
	}

	public int getLid() {
		return lid;
	}

	public void setLid(int lid) {
		this.lid = lid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}
	
	public void Display() {
		Scanner sc = new Scanner("System.in");
		System.out.println("Enter Laptop Details:");
		System.out.println("Enter Laptop name:");
		name = sc.next();
		System.out.println("Enter Laptop Cost:");
		cost = sc.nextDouble();
	}
	
}
