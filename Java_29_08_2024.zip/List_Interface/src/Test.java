// Collection Framework 
import java.util.List;
import java.util.Vector;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class Test {

	public static void main(String[] args) {

		// List Initialization 
		List<String> list1 = new ArrayList<>();
		
		// Adding items in the list 
		list1.add("Apple");
		list1.add("Banana");
		list1.add("Orange");
		
		System.out.println(list1);
		
		// Adding 
		list1.add(1,"Guava");
		
		// Removing
		list1.remove(0);
		
		System.out.println(list1);
		
		// If an item is present in the list 
		boolean isp= list1.contains("Orange");
		System.out.println(isp);
		
		// Size of the List 
		System.out.println(list1.size());
		
		System.out.println();
		
		// Iterator 
		Iterator<String> arrayitr = list1.iterator(); 
		while(arrayitr.hasNext()) {
			String l = arrayitr.next();
			System.out.println(l);
		}
		
		System.out.println();
		
		//  Vector Initialization
		Vector<String> v1 = new Vector<>();
		
		// Adding to vector 
		v1.add("Aryan");
		v1.add("Anay");
		v1.add("Amit");
		
		System.out.println(v1);
		
		// Removing 
		v1.remove("Aryan");
		
		System.out.println(v1);
		
		// If item is present in the vector 
		
		boolean ispe = v1.contains("Aryan");
		System.out.println(ispe);
		
		// Size of the Vector 
		System.out.println(v1.size());
		
		System.out.println();
		
		// Linked List Initialization 
		List<String> l1 = new LinkedList<>();
		
		// Adding to Linked List
		l1.add("Car");
		l1.add("Auto");
		l1.add("Bus");
		
		System.out.println(l1);
		
		// Removing from Linked List 
		l1.remove("Bus");
		
		System.out.println(l1);
		
		// If item is present or not 
		boolean is = l1.contains("Car");
		System.out.println(is);
		
		
		// Size of the Linked List
		System.out.println(l1.size());
		
	}

}
