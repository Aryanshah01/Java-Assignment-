package in.mindcraft;

public class SalesPerson extends WageEmployee {
	
	private int items;
	private int com;
	private int hours;
	private int rate;
	
	public SalesPerson() {
		items=0;
		com=0;
		hours=0;
		rate=0;
	}

	public SalesPerson(int items, int com, int id, String name,int dd, int mm, int yy, int h, int r) {
		super(id,name,dd,mm,yy,h,r);
		this.items = items;
		this.com = com;
		this.hours = h;
		this.rate = r;
	}
	
	public void show() {
		super.show();
		System.out.println("Items Sold:"+items);
		System.out.println("Commision per item:"+com);
		System.out.println("SalesPerson Salary:"+(hours*rate+items*com));
	}
	
	
}
