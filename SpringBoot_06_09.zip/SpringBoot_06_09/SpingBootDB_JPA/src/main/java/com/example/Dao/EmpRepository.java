package com.example.Dao;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.Entity.Emp;



@Repository
@ComponentScan(basePackages = "com.example")
public interface EmpRepository extends CrudRepository<Emp, Integer>  {

   // public  Optional<Emp> findById(int id);
    public Emp findById(int id);
    
}