import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) throws SQLException {
			
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost/student","root","root");
			
			int roll_no;
			String name;
			long marks;
			PreparedStatement psmt;

			while(true) {
				System.out.println("1. Insert Record");
				System.out.println("2. Update Record");
				System.out.println("3. Delete Record");
				System.out.println("4. Display Particular Record");
				System.out.println("5. Display All Record");
				System.out.println("6. Exit");
				Scanner sc = new Scanner(System.in);
				int choice = sc.nextInt();
				switch(choice) {
				case 1:
					System.out.println("Enter Roll Number, Name, Marks: ");
					roll_no = sc.nextInt();
					name = sc.next();
					marks = sc.nextLong();
					
					psmt = c.prepareStatement("Insert into students values(?,?,?)");
					psmt.setInt(1, roll_no);
					psmt.setString(2, name);
					psmt.setDouble(3, marks);
					
					boolean s = psmt.execute();
					if(!s) {
						System.out.println("Row Inserted Successfully");
					}
					
					break;
					
				case 2:
					System.out.println("Enter Roll Number to update Record: ");
					roll_no = sc.nextInt();
					System.out.println("Enter Updated name and marks");
					name = sc.next();
					marks = sc.nextLong();
					psmt = c.prepareStatement("Update students set name = (?), marks = (?) where roll_no = (?)");
					psmt.setInt(3, roll_no);
					psmt.setString(1, name);
					psmt.setDouble(2, marks);
					
					boolean a = psmt.execute();
					if(!a) {
						System.out.println("Row Updated Successfully");
					}
					
					break;
					
				case 3:
					System.out.println("Enter roll_no to Delete records: ");
					roll_no = sc.nextInt();
					psmt = c.prepareStatement("delete from students where roll_no = (?)");
					psmt.setInt(1, roll_no);
					boolean b = psmt.execute();
					if(!b) {
						System.out.println("Row Deleted Successfully");
					}
					
					break;
					
				case 4:
					System.out.println("Enter roll_no to Display recrods:");
					roll_no = sc.nextInt();
					psmt = c.prepareStatement("Select * from students where roll_no = (?)");
					psmt.setInt(1, roll_no);
					ResultSet rs = psmt.executeQuery();
					while(rs.next()) {
						System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getLong(3));
					}
					System.out.println();
					boolean d = psmt.execute();
					if(!d) {
						System.out.println("Row Displayed Successfully");
					}
					break;
					
				case 5:
					System.out.println("View Records: ");
					psmt = c.prepareStatement("Select * from students");
					ResultSet ts = psmt.executeQuery();
					while(ts.next()) {
						System.out.println(ts.getInt(1)+" "+ts.getString(2)+" "+ts.getLong(3));
					}
					System.out.println();
					boolean r = psmt.execute();
					if(!r) {
						System.out.println("Records Dispayed Successfully");
					}
					break;
					
				case 6:
					System.exit(0);
					break;
				}
			}
			
	}
}
