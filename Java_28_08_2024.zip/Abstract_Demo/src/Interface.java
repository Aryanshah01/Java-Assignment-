interface showable{
	void show();
}

interface printable{
	void print();
}

abstract class lib{
	abstract void store();
}

class doc extends lib implements showable,printable{
	@Override
	public void show() {
		System.out.println("Show Docs ....");
	}

	@Override
	public void print() {
		System.out.println("Print Docs ....");		
	}

	@Override
	void store() {
		System.out.println("Store Details .....");
	}
}



public class Interface {

	public static void main(String[] args) {
		doc d1 = new doc();
		d1.show();
		d1.print();
		d1.store();
	}

}

