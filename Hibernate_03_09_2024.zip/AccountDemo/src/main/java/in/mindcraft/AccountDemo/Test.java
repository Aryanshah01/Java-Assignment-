package in.mindcraft.AccountDemo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class Test {

    public static void main(String[] args) {
            	
        Accounts acc = new Accounts();
        System.out.println("Enter Account Details:");
        acc.display();

        System.out.println();
        
        Savings sacc = new Savings();
        System.out.println("Enter Savings Account Details:");
        sacc.display();
        sacc.setInterestRate(10);

        System.out.println();
        
        Current cacc = new Current();
        System.out.println("Enter Current Account Details:");
        cacc.display();
        cacc.setOverlimit(10000);

        StandardServiceRegistry standardRegistry = new StandardServiceRegistryBuilder()
                .configure()
                .build();

        MetadataSources metadataSources = new MetadataSources(standardRegistry);

        Metadata metadata = metadataSources.getMetadataBuilder().build();

        SessionFactory sessionFactory = metadata.getSessionFactoryBuilder().build();

        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        session.save(acc);
        session.save(sacc);
        session.save(cacc);

        transaction.commit();

        session.close();
        sessionFactory.close();
    }
}
