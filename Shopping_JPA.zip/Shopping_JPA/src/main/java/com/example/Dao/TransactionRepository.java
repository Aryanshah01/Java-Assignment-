package com.example.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Entity.Transaction;

public interface TransactionRepository extends JpaRepository<Transaction, Long>{

}
