import java.util.LinkedHashMap;
import java.util.Map;

public class Linked_Hash_Map {

	public static void main(String[] args) {
		
		// LinkedHashMap Initialization
		Map<Integer, String> l1 = new LinkedHashMap<>();
		
		// Adding Elements
		l1.put(1, "Aryan");
		l1.put(2, "Anay");
		l1.put(3, "Amit");
		l1.put(null, "Rohan"); 	// Allows null key
		l1.put(4, null); 		// Allows null value 
		System.out.println(l1); // Ordered of Insertion is Preserved 
		
		// Removing
		l1.remove(1, "Aryan");
		System.out.println(l1);
		
		// Size
		System.out.println(l1.size());
		
	}

}
