import java.util.Scanner;

class add{
	int a,b,c;
	
	public void subtraction() {
		System.out.println("Enter a: ");
		Scanner sc =  new Scanner(System.in);
		a = sc.nextInt();
		System.out.println("Enter b: ");
		b = sc.nextInt();
		System.out.println(a-b);
	}
	
	public void addition() {
		System.out.println("Enter a: ");
		Scanner sc = new Scanner(System.in);
		a = sc.nextInt();
		System.out.println("Enter b: ");
		b = sc.nextInt();
		System.out.println(a+b);
	}
	
	public void mul() {
		System.out.println("Enter a: ");
		Scanner sc = new Scanner(System.in);
		a = sc.nextInt();
		System.out.println("Enter b: ");
		b = sc.nextInt();
		System.out.println(a*b);
	}
	
	public void div() {
		System.out.println("Enter a: ");
		Scanner sc = new Scanner(System.in);
		a = sc.nextInt();
		System.out.println("Enter b: ");
		b = sc.nextInt();
		System.out.println(a/b);
		try {
			c = a/b;
		}
		catch(Exception e){
			System.out.println("Expection: "+e);
		}
	}
}

public class Test {

	public static void main(String[] args) {
		add cal = new add();
		String typ;
		System.out.println("Select add, sub, mul, div: ");
		Scanner sc = new Scanner(System.in);
		typ = sc.next();
		switch (typ) {
			case "add":
				cal.addition();
			break;
			case "sub":
				cal.subtraction();
			break;
			case "mul":
				cal.mul();
			break;
			case "div":
				cal.div();
			break;
		}
	}
}
