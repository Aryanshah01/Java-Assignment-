import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		
		int orignal[][] = {{1,2,3},{4,5,6},{7,8,9}};
		
		int transpose[][] = new int[3][3];
		
		for(int i=0;i<orignal.length;i++) {
			for(int j=0;j<orignal.length;j++) {
				transpose[i][j] = orignal[j][i];
			}
		}
		
		for(int i=0;i<orignal.length;i++) {
			for(int j=0;j<orignal.length;j++) {
				System.out.print(orignal[i][j]+" ");
			}
			System.out.println();
		}
		
		System.out.println();
		
		for(int i=0;i<transpose.length;i++) {
			for(int j=0; j<transpose.length;j++) {
				System.out.print(transpose[i][j]+" ");
			}
			System.out.println();
		}
		
		System.out.println();
		
		int new_array[][] = new int[3][3];
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Elements of the Matrix: ");
		for(int i=0;i<new_array.length;i++) {
			for(int j=0;j<new_array.length;j++) {
				new_array[i][j] = sc.nextInt();
			}
		}
		
		for(int i=0;i<new_array.length;i++) {
			for(int j=0;j<new_array.length;j++) {
				System.out.print(new_array[i][j]+" ");
				
			}
			System.out.println();
		}
		
		
		System.out.println();
		
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				int sum[][] = new int[3][3];
				sum[i][j] = new_array[i][j] + transpose[i][j]; 
				System.out.print(sum[i][j]+" ");
			}
			System.out.println();
		}
		
	}

}
