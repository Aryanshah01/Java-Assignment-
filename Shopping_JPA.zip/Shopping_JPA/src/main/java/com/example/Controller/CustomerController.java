package com.example.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.Entity.Cart;
import com.example.Entity.Product;
import com.example.Services.CartService;
import com.example.Services.CustomerService;
import com.example.Services.ProductService;

@RestController
@RequestMapping("/customer")
public class CustomerController {

	 private CustomerService customerService;

	    @Autowired
	    private ProductService productService;

	    @Autowired
	    private CartService cartService;

	    @PostMapping("/balance")
	    public void addBalance(@RequestParam Long customerId, @RequestParam Double amount) {
	        customerService.updateBalance(customerId, amount);
	    }

	    @GetMapping("/products")
	    public List<Product> getProducts() {
	        return productService.getAllProducts();
	    }

	    @PostMapping("/cart")
	    public Cart addToCart(@RequestBody Cart cart) {
	        return cartService.addToCart(cart);
	    }

//	    @GetMapping("/cart/{customerId}")
//	    public List<Cart> getCart(@PathVariable Long customerId) {
//	        return cartService.getCartByCustomerId(customerId);
//	    }

	    @PostMapping("/checkout")
	    public void checkout(@RequestParam Long customerId) {

	    }
	
}
