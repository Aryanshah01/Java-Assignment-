import in.mindcraft.SalesPerson;
import in.mindcraft.WageEmployee;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// WageEmployee w1 = new WageEmployee();
		// w1.show();
		
		// System.out.println();
		
		WageEmployee w2 = new WageEmployee(101, "Aryan", 10, 12, 2001, 100, 500);
		w2.show();
		
		System.out.println();
		
		SalesPerson w3 = new SalesPerson(10, 100, 101, "Aryan", 10, 12, 2001, 10, 100);
		w3.show();
	}

}
