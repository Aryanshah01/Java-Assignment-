package com.example.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "carts")
public class Cart {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long c_id;
	private Long p_id;
    private String name;
    private Double price;
    private Integer quantity;
    private Double discount;

    public Cart() {
    	
    }

	public Cart(Long c_id, Long p_id, String name, Double price, Integer quantity, Double discount) {
		super();
		this.c_id = c_id;
		this.p_id = p_id;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
		this.discount = discount;
	}

	public Long getC_id() {
		return c_id;
	}

	public void setC_id(Long c_id) {
		this.c_id = c_id;
	}

	public Long getP_id() {
		return p_id;
	}

	public void setP_id(Long p_id) {
		this.p_id = p_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Double getDiscount() {
		return discount;
	}

	public void setDiscount(Double discount) {
		this.discount = discount;
	}

	@Override
	public String toString() {
		return "Cart [c_id=" + c_id + ", p_id=" + p_id + ", name=" + name + ", price=" + price + ", quantity="
				+ quantity + ", discount=" + discount + "]";
	}
	
}
