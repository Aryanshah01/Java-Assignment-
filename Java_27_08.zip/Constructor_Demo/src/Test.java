class Car{
	String brand,model;
	int year;
	
	// Default Constructor
	Car(){
		brand="tata";
		model="SUV";
		year = 2023;
	}
	
	// Parameterized Constructor 
	Car(String b, String m, int y){
		brand = b;
		model = m;
		year = y;
		System.out.println("Parameterized Constructor Called");
	}
	
	public void display() {
		System.out.println(brand +" "+model+" "+year);
	}
	
	
}
public class Test {

	public static void main(String[] args) {

		// Calling Parameterized Constructor
		Car c1 = new Car("maruti", "suv", 2024);
		c1.display();
		
		
		// Calling Default Constructor 
		Car c2 = new Car();
		c2.display();
		
	}

}
