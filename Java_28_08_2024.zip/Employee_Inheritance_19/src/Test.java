import in.mindcraft.*;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Manager m1 = new Manager(101, "Aryan", 10000);
		//m1.show();
		
		System.out.println();
		
		Marketing m2 = new Marketing(10, 101, "Aryan", 10000);
		m2.show();
	}

}


