package in.mindcraft.controllers;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import in.mindcraft.dao.LaptopDao;
import in.mindcraft.pojos.Laptop;

@Controller
public class LaptopController {

	// DAO Class Object 
	private LaptopDao laptopdao = new LaptopDao();
	
	@RequestMapping("/insertlap")
	public void addLaptop(HttpServletRequest request, HttpServletResponse response) throws SQLException, ClassNotFoundException{
		int lid = Integer.parseInt(request.getParameter("lid"));
		String make = request.getParameter("make");
		double cost = Double.parseDouble(request.getParameter("cost"));
		
		Laptop laptop = new Laptop(lid,make,cost);
		
		//dao class will add connection method
		laptopdao.addLaptop(laptop);
	}
	
	@RequestMapping("/showlaps")
	public ModelAndView showLaptops() throws ClassNotFoundException{
		ModelAndView mv = new ModelAndView();
		try {
			List<Laptop> list = laptopdao.getLaptops();
			System.out.println(list);
			mv.setViewName("result.jsp");
			mv.addObject("list", list);
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		return mv;
	}
	
	@RequestMapping("/updatelaps")
	public void updateLaptop(HttpServletResponse response, HttpServletRequest request) throws SQLException, ClassNotFoundException{
		int lid = Integer.parseInt(request.getParameter("lid"));
		String make = request.getParameter("make");
		double cost = Double.parseDouble(request.getParameter("cost"));
		
		Laptop laptop = new Laptop(lid,make,cost);
		
		laptopdao.updateLaptop(laptop);
	}
	
	@RequestMapping("/deletelaps")
	public void deleteLaptop(HttpServletResponse response, HttpServletRequest request) throws SQLException, ClassNotFoundException{
		int lid = Integer.parseInt(request.getParameter("lid"));
		
		laptopdao.deleteLaptop(lid);
	}
}
