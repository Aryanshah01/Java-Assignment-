package in.mindcraft;

public class Employee {
	private int empid;
	private String name;
	private int b_sal;
	
	public Employee() {
		empid=101;
		name="Aryan";
		b_sal=1000;
	}

	public Employee(int empid, String name, int b_sal) {
		this.empid = empid;
		this.name = name;
		this.b_sal = b_sal;
	}
	
	public void show() {
		System.out.println("Employee ID:"+empid);
		System.out.println("Employee Name:"+name);
		System.out.println("Employee Salary:"+b_sal);
	}
	
	
	
}
