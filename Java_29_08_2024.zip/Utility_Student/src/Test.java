import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class UtilityList{
	int rollno;
	String name;
	int grade;
	double per;
	
	public UtilityList(){
		rollno = 101;
		name = "Aryan";
		grade=10;
		per = 100;
	}

	public UtilityList(int rollno, String name, int grade, double per) {
		super();
		this.rollno = rollno;
		this.name = name;
		this.grade = grade;
		this.per = per;
	}
	
	public void CreateList() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter RollNo: ");
		rollno = sc.nextInt();
		System.out.println("Enter name: ");
		name = sc.next();
		System.out.println("Enter Grade: ");
		grade = sc.nextInt();
		System.out.println("Enter Percentage: ");
		per = sc.nextDouble();
	}

	@Override
	public String toString() {
		return "UtilityList [rollno=" + rollno + ", name=" + name + ", grade=" + grade + ", per=" + per + "]";
	}
	
}



public class Test {

	public static void main(String[] args) {
		
		List<UtilityList> l1 = new ArrayList<UtilityList>();
		Scanner sc = new Scanner(System.in);
		while(true) {
			int choice;
			System.out.println("1. Add Student Details: ");
			System.out.println("2. Display Student Details: ");
			System.out.println("3. Exit");
			System.out.println("Enter Your Choice:");
			choice = sc.nextInt();
			switch(choice) {
			case 1:
				UtilityList e1 = new UtilityList();
				e1.CreateList();
				l1.add(e1);
				break;
				
			case 2:
				System.out.println("Details of the Students: ");
				for(int i=0;i<l1.size();i++) {
					System.out.println(l1.get(i).rollno+" "+l1.get(i).name+" "+l1.get(i).grade+" "+l1.get(i).per);
				}
				System.out.println();
				break;
				
			case 3:
				System.exit(0);
			}
		}
		
	}

}
