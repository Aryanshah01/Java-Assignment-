import java.util.Scanner;

class Rev{
	int reverse = 0;
	
	public void func() {
		System.out.println("Enter a number: ");
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		while(num!=0) {
			int remainder = num % 10;
			reverse = reverse*10 + remainder;
			num = num/10;
		}
		
		System.out.println("The reversed number is: "+ reverse);
	}
}



public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rev fun = new Rev();
		fun.func();
	}

}
