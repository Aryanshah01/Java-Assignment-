package in.mindcraft.AccountDemo;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@DiscriminatorValue("Current")
@Table(name="Curr_Acc")
public class Current extends Accounts {

    @Column(name = "overlimit")
    private double overlimit;

    public double getOverlimit() {
        return overlimit;
    }

    public void setOverlimit(double overlimit) {
        this.overlimit = overlimit;
    }
}
