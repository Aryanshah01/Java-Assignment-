import java.util.Scanner;

class Sum{
	int digit,sum=0;
	public void sumofdigits() {
		System.out.println("Enter a number: ");
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		while(num>0){
			digit = num%10;
			sum += digit;
			num = num/10;
			
			System.out.println("Sum of Digits: " + sum);
		}
	}
}

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sum fun = new Sum();
		fun.sumofdigits();
	}

}
