// Collection Framework
import java.util.Set;
import java.util.HashSet;

public class Hash_Set {

	public static void main(String[] args) {
		
		// Set Initialization 
		Set<String> hash_s1 = new HashSet<>();
		
		// Add items in HashSet 
		hash_s1.add("Aryan"); 
		hash_s1.add("Aryan"); // Duplicate Entry will be ignored 
		hash_s1.add("Anay");
		hash_s1.add("Amit");
		
		System.out.println(hash_s1); //  Order of insertion of elements is not preserved 
		
		// Remove items in HashSet
		hash_s1.remove("Aryan");
		
		System.out.println(hash_s1);
		
		// Is present
		boolean isp = hash_s1.contains("Aryan");
		System.out.println(isp);
		
		// Size of the HashSet
		System.out.println(hash_s1.size());
		
		
	}

}
