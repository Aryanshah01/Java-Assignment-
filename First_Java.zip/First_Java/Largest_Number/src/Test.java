import java.util.Scanner;

class Largest{
	int a,b,c,temp,largest;
	
	public void func() {
		System.out.println("Enter the first number: ");
		Scanner sc = new Scanner(System.in);
		a = sc.nextInt();
		System.out.println("Enter the second number: ");
		b = sc.nextInt();
		System.out.println("Enter the third number: ");
		c = sc.nextInt();
		
		temp = a>b?a:b;
		largest = c>temp?c:temp;
		
		System.out.println("The largest number is: " + largest);
	}
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Largest fun = new Largest();
		fun.func();
	}

}
