// Collection Framework
import java.util.TreeSet;

public class Tree_Set {

	public static void main(String[] args) {
		
		// TreeSet Initialization 
		TreeSet<String> t1 = new TreeSet<>();
		
		// Adding Elements 
		t1.add("Aryan");
		t1.add("Anay");
		t1.add("Amit");
		t1.add("Amit"); // Duplicate entry will be ignored 
		
		System.out.println(t1); // Order of the set is sorted 
		
		// Removing Elements 
		t1.remove("Aryan");
		
		System.out.println(t1);
		
		
		// Is Present 
		boolean isp = t1.contains("Aryan");
		System.out.println(isp);
		
		// Size of the TreeSet
		System.out.println(t1.size());
		
		// Loop will display elements in an order 
		for(String name:t1) {
			System.out.println(name);
		}
	}

}
