import java.util.Scanner;

class EvenOdd{
	int a;
	
	public void fun() {
		System.out.println("Enter a number: ");
		Scanner sc = new Scanner(System.in);
		a = sc.nextInt();
		if(a%2==0)
			System.out.println(a + " is even");
		else
			System.out.println(a + " is odd");
	}
}


public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EvenOdd test = new EvenOdd();
		test.fun();
	}

}
