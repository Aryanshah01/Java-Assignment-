package in.mindcraft;

public class WageEmployee extends Employee{
	
	private int hours;
	private int rate;
	
	public WageEmployee() {
		hours =0;
		rate=0;
	}

	public WageEmployee(int id, String name,int dd, int mm, int yy, int h, int r) {
		super(id, name,dd, mm, yy);
		this.hours = h;
		this.rate = r;
	}
	
	public void show() {
		super.show();
		System.out.println("Hours: "+hours);
		System.out.println("Rate: "+rate);
		System.out.println("Wage of Employee: "+hours*rate);
	}
	

}
