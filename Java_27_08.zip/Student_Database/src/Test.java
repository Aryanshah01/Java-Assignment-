import java.util.Scanner;

class Students{
	private int roll_no;
	private String name;
	private int percentage;
	static int count = 0;
	
	public Students(int roll_no, String name, int percentage) {
		super();
		this.roll_no = roll_no;
		this.name = name;
		this.percentage = percentage;
		count++;
	}

	public int getRoll_no() {
		return roll_no;
	}

	public void setRoll_no(int roll_no) {
		this.roll_no = roll_no;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPercentage() {
		return percentage;
	}

	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}

	static int getCount() {
		return count;
	}

	public void Details() {
	System.out.println(roll_no+"\t"+name+"\t"+percentage);
	}
	
}

public class Test {

	public static void main(String[] args) {
		
		int count=0,choice;
		Students stud[] = new Students[10];
		
		
		Scanner sc = new Scanner(System.in);
		while(true) {
			
			System.out.println("1. Enter Student Details: ");
			System.out.println("2. Show Student Count: ");
			System.out.println("3. All Student Details");
			
			System.out.println("Enter Choice: ");
			choice = sc.nextInt();
			
			switch(choice) {
			
			case 1:
				System.out.println("Roll_No, Name, Percentage");
				stud[count++] = new Students(sc.nextInt(),sc.next(),sc.nextInt());
				break;
				
				
			case 2:
				System.out.println("Show student Count: ");
				System.out.println(Students.getCount());
				
			case 3:
				System.out.println("All Student Details: ");
				for(int j=0;j<count;j++) {
					stud[j].Details();
				}
				break;
				
			case 4:
				System.exit(0);
			}		
		}
		
	}

}
