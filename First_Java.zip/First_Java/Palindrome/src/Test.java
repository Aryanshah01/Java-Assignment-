import java.util.Scanner;

class Palindrome{
	boolean flag = true;
	public void pali() {
		System.out.println("Enter a string: ");
		Scanner sc = new Scanner(System.in);
		String name = sc.next();
		name = name.toLowerCase();
		for(int i=0;i<name.length()/2;i++) {
			if(name.charAt(i)!=name.charAt(name.length()-i-1)) {
				flag = false;
				break;
			}
		}
		
		if(flag)
			System.out.println("Given string is palindrome.");
		else
			System.out.println("Given string is not a palindrome");
	}
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Palindrome fun = new Palindrome();
		fun.pali();
	}

}
