package com.example.Dao;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.Entity1.Book;

	@Repository
	@ComponentScan(basePackages = "com.example")
	public interface BookRepository extends CrudRepository<Book, Integer>{
		public Book findById(int bid);
}
	
