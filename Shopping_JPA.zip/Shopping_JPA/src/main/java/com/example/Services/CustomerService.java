package com.example.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Dao.CustomerRepository;
import com.example.Entity.Customer;

@Service
public class CustomerService {

	@Autowired
	private CustomerRepository customerRepository;

    public Customer getCustomerByUsername(String username) {
        return customerRepository.findByUsername(username);
    }

    public Customer addCustomer(Customer customer) {
        return customerRepository.save(customer);
    }

    public void updateBalance(Long customerId, Double amount) {
        Customer customer = customerRepository.findById(customerId).orElseThrow();
        customer.setBalance(customer.getBalance() + amount);
        customerRepository.save(customer);
    }
}
