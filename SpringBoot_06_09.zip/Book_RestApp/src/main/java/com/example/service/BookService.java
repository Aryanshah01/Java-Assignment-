package com.example.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.example.entity.*;

@Component
public class BookService {
	
	public static List<Book> list=new ArrayList<>();
	
	static {
		list.add(new Book(1, "GameOfThrones", "George", 1000));
		list.add(new Book(2, "Atomic", "Aryan", 100));
	}

	public List<Book> getAllBook(){
		return list;
	}
	
		public Book getBookById(int id) {		
			Book book=null;
			book=list.stream().filter(e->e.getBid()==id).findFirst().get();
			return book;
		}

		public void addBook(Book b) {
			list.add(b);
		}

		public void deleteBook(int bid) {
			list=list.stream().filter(emp->emp.getBid()!=bid).collect(Collectors.toList());
		}

		public void updateBook(Book book,int bId) {
			list=list.stream().map(b->{
				if(b.getBid()==bId) {
					b.setName(book.getName());
					b.setAuthor(book.getAuthor());
				}
				return b;
			}).collect(Collectors.toList());
		}
		
}