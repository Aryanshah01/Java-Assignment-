import java.util.Scanner;

class Prime {
	int n;
	public void func() {
		System.out.println("Enter a number: ");
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		int t = 0;
		if (n>2) {
		for (int i=2; i<n; i++) {
			if (n%i == 0) {
				t = 1;
				break;
			}}
		if (t == 0) {
			System.out.println("PRIME");
		}
		else {
			System.out.println("NOT PRIME");
		
		}
		}
		if (n==2) {
			System.out.println("PRIME");
		}
		else { 
			System.out.println("ENTER IN 2-INFINITE");
		}
	}}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Prime fun = new Prime();
		fun.func();
	}

}
