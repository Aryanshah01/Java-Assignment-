package in.mindcraft.controllers;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import in.mindcraft.daos.BookDao;
import in.mindcraft.pojos.Book;

@Controller
public class BookControllers {
private BookDao bookdao = new BookDao();
	
	@RequestMapping("/insertBooks")
	public void addBook(HttpServletRequest request, HttpServletResponse response) throws SQLException, ClassNotFoundException{
		int b_id = Integer.parseInt(request.getParameter("b_id"));
		String make = request.getParameter("make");
		String author = request.getParameter("author");
		double cost = Double.parseDouble(request.getParameter("cost"));
		
		Book book = new Book(b_id, make, author, cost);
		
		bookdao.addBook(book);
	}
	
	@RequestMapping("/showBooks")
	public ModelAndView showBook() throws ClassNotFoundException{
		ModelAndView mv = new ModelAndView();
		try {
			List<Book> list = bookdao.getBooks();
			System.out.println(list);
			mv.setViewName("result.jsp");
			mv.addObject("list", list);
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		return mv;
	}
	
	@RequestMapping("/updateBooks")
	public void updateBook(HttpServletResponse response, HttpServletRequest request) throws SQLException, ClassNotFoundException{
		int b_id = Integer.parseInt(request.getParameter("b_id"));
		String make = request.getParameter("make");
		String author = request.getParameter("author");
		double cost = Double.parseDouble(request.getParameter("cost"));
		
		Book book = new Book(b_id, make, author, cost);
		
		bookdao.updateBook(book);
	}
	
	@RequestMapping("/deleteBooks")
	public void deleteBook(HttpServletResponse response, HttpServletRequest request) throws SQLException, ClassNotFoundException{
		int b_id = Integer.parseInt(request.getParameter("b_id"));
		
		bookdao.deleteBook(b_id);
	}

}
