package com.example.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Dao.CartRepository;
import com.example.Entity.Cart;

@Service
public class CartService {

	@Autowired
	 private CartRepository cartRepository;

//	    public List<Cart> getCartByCustomerId(Long customerId) {
//	    	return cartRepository.findByCustomerId(customerId);
//	    }
	    
	    public Cart addToCart(Cart cart) {
	        return cartRepository.save(cart);
	    }

	    public void removeFromCart(Long cartId) {
	        cartRepository.deleteById(cartId);
	    }	
}
