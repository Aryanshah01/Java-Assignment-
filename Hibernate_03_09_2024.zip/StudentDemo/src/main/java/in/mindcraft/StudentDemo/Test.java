package in.mindcraft.StudentDemo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class Test {

	public static void main(String[] args) {
		
		Student s1 = new Student();
		s1.setSid(100);
		s1.setName("Aryan");
		
		Student s2 = new Student();
		s2.setSid(101);
		s2.setName("Sam");
		
		Laptop l1 = new Laptop();
		l1.setLid(1);
		l1.setLname("Lenevo");
		l1.setMake(10000);
		
		Laptop l2 = new Laptop();
		l2.setLid(2);
		l2.setLname("Apple");
		l2.setMake(100000);
		
		Laptop l3 = new Laptop();
		l3.setLid(3);
		l3.setLname("Dell");
		l3.setMake(10000);
		
		s1.getList_01().add(l1);
		s1.getList_01().add(l2);
		s2.getList_01().add(l2);
		s2.getList_01().add(l3);
		l1.getList_02().add(s2);
		l2.getList_02().add(s2);
		
		
		StandardServiceRegistry standardRegistry = new StandardServiceRegistryBuilder()
				.configure()
				.build();
		
		MetadataSources metadataSources = new MetadataSources(standardRegistry);
		
		Metadata metadata = metadataSources.getMetadataBuilder().build();
		
		SessionFactory sessionFactory = metadata.getSessionFactoryBuilder().build();
		
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		
		session.save(s1);
		session.save(s2);
		session.save(l1);
		session.save(l2);
		
		transaction.commit();
		
		session.close();
		sessionFactory.close();
		
		
	}

}
