package in.mindcraft;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Calc {
	
	@RequestMapping("/add")
	public ModelAndView add(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("Calculator Display..");
		int a=Integer.parseInt(request.getParameter("a"));
		int b=Integer.parseInt(request.getParameter("b"));
		int c=a+b;
		ModelAndView mv = new ModelAndView();
		mv.setViewName("result.jsp");
		mv.addObject("c", c);
		return mv;
	}

	@RequestMapping("/sub")
	public ModelAndView sub(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("Calculator Display..");
		int a=Integer.parseInt(request.getParameter("a"));
		int b=Integer.parseInt(request.getParameter("b"));
		int c=a-b;
		ModelAndView mv = new ModelAndView();
		mv.setViewName("result.jsp");
		mv.addObject("c", c);
		return mv;
	}
	
	@RequestMapping("/mul")
	public ModelAndView mul(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("Calculator Display..");
		int a=Integer.parseInt(request.getParameter("a"));
		int b=Integer.parseInt(request.getParameter("b"));
		int c=a*b;
		ModelAndView mv = new ModelAndView();
		mv.setViewName("result.jsp");
		mv.addObject("c", c);
		return mv;
	}
	
	@RequestMapping("/div")
	public ModelAndView div(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("Calculator Display..");
		int a=Integer.parseInt(request.getParameter("a"));
		int b=Integer.parseInt(request.getParameter("b"));
		int c=a/b;
		ModelAndView mv = new ModelAndView();
		mv.setViewName("result.jsp");
		mv.addObject("c", c);
		return mv;
	}
}
