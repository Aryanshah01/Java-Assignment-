import pack1.Students;
import pack2.Batch;



public class TestMain {
    public static void main(String[] args) {
        // Creating objects of Student and Batch classes
        Students student1 = new Students(1, "Devansh");
        Students student2 = new Students(2, "Aryan");

        Batch batch1 = new Batch("Computer Science", 30);
        Batch batch2 = new Batch("IT", 30);

        student1.display();
        student2.display();

        batch1.display();
        batch2.display();
    }
}
