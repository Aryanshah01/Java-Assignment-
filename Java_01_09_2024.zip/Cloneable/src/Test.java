
class Vehicle implements Cloneable{
	private String vname;
	private int vnum;
	private double cost;
	
	public Vehicle() {
		vname = "Merc";
		vnum = 101;
		cost = 10000;
	}
	
	public Vehicle(String vname, int vnum, double cost) {
		super();
		this.vname = vname;
		this.vnum = vnum;
		this.cost = cost;
	}
	
	public void show() {
		System.out.println(vname+" "+vnum+" "+cost);
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}



}
public class Test {

	public static void main(String[] args) throws CloneNotSupportedException {

		Vehicle v = new Vehicle("BMW", 101, 30000000);
		v.show();
		
		Vehicle v1 = (Vehicle)v.clone();
		v1.show();
		
		
	}

}
