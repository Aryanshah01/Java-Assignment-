import java.util.Scanner;

class Fact{
	int i;
	int fact = 1;
	public void fun() {
		System.out.println("Enter a number: ");
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		for(i=1;i<=num;i++) {
			fact = fact*i;
			
		System.out.println("Factorial of " + num +" is:" + fact);
		}
	}
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Fact test = new Fact();
		test.fun();
	}

}
