package in.mindcraft.StudentDemo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;



@Entity
public class Laptop {

	@Id
	private int lid;
	private String Lname;
	private double make;
	
	public int getLid() {
		return lid;
	}
	public void setLid(int lid) {
		this.lid = lid;
	}
	public String getLname() {
		return Lname;
	}
	public void setLname(String lname) {
		Lname = lname;
	}
	public double getMake() {
		return make;
	}
	public void setMake(double make) {
		this.make = make;
	}
	

	@ManyToMany
	List<Student> list_02 = new ArrayList<Student>();

	public List<Student> getList_02() {
		return list_02;
	}
	public void setList_02(List<Student> list_02) {
		this.list_02 = list_02;
	}
	
	
}
