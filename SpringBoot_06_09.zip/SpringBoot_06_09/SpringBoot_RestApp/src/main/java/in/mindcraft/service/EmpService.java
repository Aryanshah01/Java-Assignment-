package in.mindcraft.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import in.mindcraft.entity.Emp;

@Component
public class EmpService {
	
	public static List<Emp> list=new ArrayList<>();
	
	static {
		list.add(new Emp(10, "vayu", "Research"));
		list.add(new Emp(20, "rohan", "IT"));
	}

	//get all emp service
	public List<Emp> getAllEmp(){
		return list;
	}
	
	//get emp by id
		public Emp getEmpById(int id) {
			
			Emp emp=null;
			// lambda function
			emp=list.stream().filter(e->e.getId()==id).findFirst().get();
			return emp;
		}
		
		//add new emp
		public void addEmp(Emp e) {
			list.add(e);
		}
		
}