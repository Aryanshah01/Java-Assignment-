class animal1{
	public void sound() {
		System.out.println("Animal makes sound .....");
	}
}

class dog1 extends animal1{
	public void sound() {
		System.out.println("Dog Barks ....");
	}
}

public class Animal_Demo {

	public static void main(String[] args) {
		animal1 a1 = new animal1();
		a1.sound();
		
		// Override class animal to get dog sound 
		animal1 a2 = new dog1();
		a2.sound();
	}

}
