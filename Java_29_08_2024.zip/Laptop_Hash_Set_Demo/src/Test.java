import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

class laptop implements Comparable<laptop>{
	private int lid;
	private String make;
	private double cost;
	
	
	public laptop(int lid, String make, double cost) {
		super();
		this.lid = lid;
		this.make = make;
		this.cost = cost;
	}
	
	public void show() {
		System.out.println(lid+" "+make+" "+cost);
	}


	@Override
	public int compareTo(laptop o) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(cost, lid, make);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		laptop other = (laptop) obj;
		return Double.doubleToLongBits(cost) == Double.doubleToLongBits(other.cost) && lid == other.lid
				&& Objects.equals(make, other.make);
	}

	public int getlid() {
		// TODO Auto-generated method stub
		return 0;
	}
}

class laptopcompare implements Comparator<laptop>{

	@Override
	public int compare(laptop o1, laptop o2) {
		if(o1.getlid()<o2.getlid()) {
			return -1;
		}
		else if(o1.getlid()>o2.getlid()) {
			return 1;
		}
		else {
			return 0;
		}
	}
	
}



public class Test {

	public static void main(String[] args) {
		
		Set<laptop> t1 = new TreeSet<laptop>();
		t1.add(new laptop(101,"Dell",20000));
		t1.add(new laptop(102,"HP",30000));
		t1.add(new laptop(102,"HP",30000));
		t1.add(new laptop(103,"Lenevo",3000));
		t1.add(new laptop(104,"Apple",50000));
		

		System.out.println(t1);
		
	}

}
