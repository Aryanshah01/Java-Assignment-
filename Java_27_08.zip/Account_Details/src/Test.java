import java.util.Scanner;

class AccountHolder{

	private int acc_no;
	private String acc_name;
	private double balance;
	
	// Generate Parameterized Constructor 
	public AccountHolder(int acc_no, String acc_name, double balance) {
		this.acc_no = acc_no;
		this.acc_name = acc_name;
		this.balance = balance;
	}

	// Generate Getter Setter 
	public int getAcc_no() {
		return acc_no;
	}


	public void setAcc_no(int acc_no) {
		this.acc_no = acc_no;
	}


	public String getAcc_name() {
		return acc_name;
	}


	public void setAcc_name(String acc_name) {
		this.acc_name = acc_name;
	}


	public double getBalance() {
		return balance;
	}


	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public void Deposit(double amount) {
		balance += amount;
	}
	
	public void Withdraw(double amount) {
		balance -= amount;
	}
	
	public void Details() {
		System.out.println(acc_no+"\t"+acc_name+"\t"+balance);
	}
	
}



public class Test {
	
	
	public static void main(String[] args) {
		
		int count=0,choice,acc_no;
		
		// Array of Objects
		AccountHolder acc[] = new AccountHolder[10];
		
		Scanner sc = new Scanner(System.in);
		while(true) {
			System.out.println("1. Add Account Details: ");
			System.out.println("2. Display Account Details: ");
			System.out.println("3. Deposit Amount: ");
			System.out.println("4. Withdraw Ammount: ");
			System.out.println("5. Exit: ");
			
			System.out.println("Enter your Choice: ");
			choice = sc.nextInt();
			switch(choice) {
			case 1:
				System.out.println("Enter Acc_no, Acc_name, Balance");
				acc[count++] = new AccountHolder(sc.nextInt(), sc.next(),sc.nextDouble());
				break;
			
			case 2:
				System.out.println("All Account Details: ");
				for(int i=0;i<count;i++) {
					acc[i].Details();
				}
				break;
				
			case 3:
				System.out.println("Enter Account Number for Deposit");
				acc_no = sc.nextInt();
				int fl = 0;
				for(int i=0;i<count;i++) {
					if(acc_no == acc[i].getAcc_no()) {
						fl = 1;
						System.out.println("Enter Deposit Ammount");
						acc[i].Deposit(sc.nextDouble());
					}
				}
				if (fl==1) {
					System.out.println("Amount Depsoited");
				}
				else {
					System.out.println("Account Detail not found");
				}
				break;
				
			case 4:
				System.out.println("Enter Account Number for Withdraw");
				acc_no = sc.nextInt();
				int fla = 0;
				for(int i=0;i<count;i++) {
					if(acc_no == acc[i].getAcc_no()) {
						fla = 1;
						System.out.println("Enter Withdrawal Amount");
						double wamt = sc.nextDouble();
						if(wamt<=acc[i].getBalance()) {
							acc[i].Withdraw(wamt);
						}
						else {
							System.out.println("Insufficient Balance");
						}
					}
				}
				if (fla==1) {
					System.out.println("Amount Withdrawn");
				}
				else {
					System.out.println("Account Detail not found");
				}
				break;

				
			case 5:
				System.exit(0);
			}
		}	
	}
}
