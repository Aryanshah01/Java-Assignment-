package pack1;


public class Students{
	int roll_no;
	String name;
	
	public Students(int roll_no, String name) {
		this.name = name;
		this.roll_no = roll_no;
	}
	
    public void display() {
        System.out.println("Student [RollNo=" + roll_no + ", Name=" + name + "]");
    }
}
