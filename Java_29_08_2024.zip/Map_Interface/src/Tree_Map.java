import java.util.Map;
import java.util.TreeMap;

public class Tree_Map {

	public static void main(String[] args) {

		// TreeMap Initialization
		Map<Integer, String> l1 = new TreeMap<>();
		
		// Adding Elements
		l1.put(1, "Aryan");
		l1.put(2, "Anay");
		l1.put(3, "Amit");
	 // l1.put(null, "Rohan"); 	// Does not allow null key
		l1.put(4, null); 		// Allows null value 
		System.out.println(l1); // Ordered by Key 
				
		// Removing
		l1.remove(1, "Aryan");
		System.out.println(l1);
				
		// Size
		System.out.println(l1.size());
			
	}

}
