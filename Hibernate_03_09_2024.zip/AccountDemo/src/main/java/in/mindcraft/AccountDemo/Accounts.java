package in.mindcraft.AccountDemo;

import java.util.Scanner;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;


@Entity
@Inheritance(strategy = InheritanceType.JOINED)
@DiscriminatorColumn(name = "DTYPE", discriminatorType = DiscriminatorType.STRING)
@Table(name = "acctable")

public class Accounts {	
	 	@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "AccountID")
	    private int accid;

	    @Column(name = "name")
	    private String name;

	    @Column(name = "balance")
	    private double balance;
	    
	    public Accounts() {
	    	name = "Aryan";
	    	balance = 1000;
	    }

	    public int getAccid() {
	        return accid;
	    }

	    public void setAccid(int accid) {
	        this.accid = accid;
	    }

	    public String getName() {
	        return name;
	    }

	    public void setName(String name) {
	        this.name = name;
	    }

	    public double getBalance() {
	        return balance;
	    }

	    public void setBalance(double balance) {
	        this.balance = balance;
	    }
	    
	    public void display() {
	    	@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
	    	System.out.println("Enter Name: ");
	    	name = sc.next();
	    	System.out.println("Enter Balance: ");
	    	balance = sc.nextDouble();
	    }
	}
