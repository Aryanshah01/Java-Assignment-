import java.util.HashMap;
import java.util.Map;

public class Hash_Map {

	public static void main(String[] args) {
		
		// HashMap Initialization
		Map<Integer,String> m1 = new HashMap<>();
		
		// Adding Elements 
		m1.put(1, "Aryan");
		m1.put(2, "Anay");
		m1.put(3, "Amit");
		m1.put(null, "Rohan"); // Null key will be printed first
		m1.put(4, null);
		System.out.println(m1); // Ordered by Key
		
		// Removing
		m1.remove(1, "Aryan");
		System.out.println(m1);
		
		// Size
		System.out.println(m1.size());
		
	}

}
