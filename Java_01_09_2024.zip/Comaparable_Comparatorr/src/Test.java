import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Person implements Comparable<Person>{

	String name;
	int age;
	
	public Person(){
		name = "Aryan";
		age = 21;
	}

	public Person(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}
	
	@Override
	public int compareTo(Person o) {
		return Integer.compare(this.age, o.age);
	}
	
	
}
public class Test {

	public static void main(String[] args) {
		List<Person> people = new ArrayList<Person>();
		people.add(new Person("Aryan", 22));
		people.add(new Person("Anay", 21));
		people.add(new Person("Amit", 45));
		
		Collections.sort(people);
		System.out.println(people);
	}

}
