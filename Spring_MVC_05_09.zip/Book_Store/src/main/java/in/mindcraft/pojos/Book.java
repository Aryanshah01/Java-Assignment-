package in.mindcraft.pojos;

public class Book {
	
	private int b_id;
	private String make;
	private String author;
	private double cost;
	
	public Book() {
		
	}

	public Book(int b_id, String make, String author, double cost) {
		super();
		this.b_id = b_id;
		this.make = make;
		this.author = author;
		this.cost = cost;
	}

	public int getB_id() {
		return b_id;
	}

	public void setB_id(int b_id) {
		this.b_id = b_id;
	}

	public String getMake() {
		return make;
	}

	public void setName(String name) {
		this.make = name;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	@Override
	public String toString() {
		return "Book [b_id=" + b_id + ", make=" + make + ", Author=" + author + ", cost=" + cost + "]";
	}
	
}
