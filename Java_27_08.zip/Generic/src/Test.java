class Math<G>{
	G g1;
	Math(G g1){
		this.g1=g1;
	}
	
	public void display() {
		System.out.println(g1);
	}
	
	public void swap(G a,G b) {
		G temp;
		temp = a;
		a = b;
		b = temp;
		System.out.println(a +" "+ b);
	}
	
	public<U> boolean isEqual(U val1, U val2) {
		return val1.equals(val2);
	}
}


public class Test {

	public static void main(String[] args) {
		
		Math<Integer> m1 = new Math<>(10);
		Math<String> m2 = new Math<>("Aryan");
		m1.display();
		m2.display();
		
		m1.swap(10, 20);
		m2.swap("Aryan", "Shah");
		System.out.println(m1.isEqual(10, 10));
	}

}
