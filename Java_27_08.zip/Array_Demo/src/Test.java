import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		
		// 1D Array
		int [] a = new int[5]; // un-initialized 
		int [] b = {10,20,30}; // initialized 
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 5 numbers: ");
		
		int i;
		for(i=0; i<a.length;i++) {
			a[i] = sc.nextInt();
		}
		
		System.out.println(a[i]);
		
		
	}

}
