package in.mindcraft.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import in.mindcraft.pojos.Book;
import in.mindcraft.utils.DBUtils;

public class BookDao {
private Connection cn;
	
	private PreparedStatement pst1;
	private PreparedStatement pst2;
	private PreparedStatement pst3;
	private PreparedStatement pst4;
	
	public void addBook(Book book) throws SQLException, ClassNotFoundException{
		cn = DBUtils.openConnection();
		pst1 = cn.prepareStatement("insert into books values(?,?,?,?)");
		pst1.setInt(1, book.getB_id());
		pst1.setString(2, book.getMake());
		pst1.setString(3, book.getAuthor());
		pst1.setDouble(4, book.getCost());
		pst1.execute();
		
		DBUtils.closeConnection();
	}
	
	public List<Book> getBooks() throws SQLException, ClassNotFoundException{
		cn = DBUtils.openConnection();
		List<Book> list = new ArrayList<Book>();
		pst2 = cn.prepareStatement("select * from laptop");
		ResultSet rs = pst2.executeQuery();
		while(rs.next()) {
			list.add(new Book(rs.getInt(1), rs.getString(2),rs.getString(3), rs.getDouble(4)));
		}
		
		DBUtils.closeConnection();
		return list;
	}
	
	public void updateBook(Book book) throws SQLException, ClassNotFoundException{
		cn = DBUtils.openConnection();
		pst3 = cn.prepareStatement("update books set make = (?), author = (?), cost = (?) where b_id = (?)");
		pst3.setInt(4, book.getB_id());
		pst3.setString(1, book.getMake());
		pst3.setString(2, book.getAuthor());
		pst3.setDouble(3, book.getCost());
		pst3.execute();
		
		DBUtils.closeConnection();
	}
	
	public void deleteBook(int b_id) throws SQLException, ClassNotFoundException{
		cn = DBUtils.openConnection();
		pst4 = cn.prepareStatement("delete from books where b_id = ?");
		pst4.setInt(1, b_id);
		pst4.execute();
		
		DBUtils.closeConnection();
	}
	
}
