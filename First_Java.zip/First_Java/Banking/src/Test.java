import java.util.Scanner;

class Banking{
	int accno, balance, wamount, damount;
	String name;
	
	public void Details() {
		System.out.println("Name: ");
		Scanner sc3 = new Scanner(System.in);
		name = sc3.next();
		System.out.println("AccNo: ");
		accno = sc3.nextInt();
	}
	
	public void Deposit() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Balance: ");
		balance = sc.nextInt();
		System.out.println("Damount:  ");
		damount = sc.nextInt();
		balance = balance + damount;
		System.out.println("Final Balance: " + balance);
	}
		
	public void Withdraw() {
			Scanner sc1 = new Scanner(System.in);
			System.out.println("Balance: ");
			balance = sc1.nextInt();
			System.out.println("Wamount: ");
			wamount = sc1.nextInt();
			balance = balance - wamount;
			System.out.println("Final Balance: " + balance);

		}
		
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Banking fun = new Banking();
		fun.Details();
		String opn;
		System.out.println("Withdraw, Deposit, Details");
		Scanner sc2 = new Scanner(System.in);
		opn = sc2.next();
		switch(opn) {
		case "Deposit":
			fun.Deposit();
			break;
		case "Withdraw":
			fun.Withdraw();
			break;
		case "Details":
			fun.Details();
			break;
		}
		
		}
	}

