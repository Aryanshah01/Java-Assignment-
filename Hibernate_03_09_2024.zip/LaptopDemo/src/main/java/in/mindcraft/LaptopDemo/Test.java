package in.mindcraft.LaptopDemo;


import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;

public class Test {

	public static void main(String[] args) {
    	
        Laptop l1 = new Laptop();
        l1.setName("Apple");
        l1.setCost(100000);
        
        Laptop l2 = new Laptop();
        l2.setName("Dell");
        l2.setCost(15000);
        
        Laptop l3 = new Laptop();
        l3.setName("HP");
        l3.setCost(10000);

       
        StandardServiceRegistry standardRegistry = new StandardServiceRegistryBuilder()
                .configure() 
                .build();

        MetadataSources metadataSources = new MetadataSources(standardRegistry);

        Metadata metadata = metadataSources.getMetadataBuilder().build();

        SessionFactory sessionFactory = metadata.getSessionFactoryBuilder().build();

        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();


        session.save(l1);
        session.save(l2);
        session.save(l3);

//        Query<Laptop> q = session.createQuery("from Laptop where cost >= 100000", Laptop.class);
//        List<Laptop> mlist = q.list();
//        for (Laptop m : mlist)
//            System.out.println(m);

        transaction.commit();

        Scanner sc = new Scanner(System.in);
        int choice;
        int result;

        while (true) {
        	System.out.println("1. Update Laptop Details:");
            System.out.println("2. Delete Laptop Details:");
            System.out.println("3. Exit:");
            System.out.println("Please select the Operation:");

            choice = sc.nextInt();

            switch (choice) {            		
            	case 1:      		
            		System.out.println("Enter Laptop ID to Update:");
            		int laptopIdToUpdate = sc.nextInt();
            		
            		transaction = session.beginTransaction();
            		@SuppressWarnings("rawtypes")
            		Query updateQuery = session.createQuery("update Laptop set name = :name, cost = :cost where lid = :lid");
            		updateQuery.setParameter("lid", laptopIdToUpdate);
            		System.out.println("Enter Laptop Name:");
            		updateQuery.setParameter("name", sc.next());
            		System.out.println("Enter Laptop Cost:");
            		updateQuery.setParameter("cost", sc.nextDouble());
            		result = updateQuery.executeUpdate();
            		System.out.println("Rows Updated Successfully");
            		
            		transaction.commit();
            		break;
            	
                case 2:
                    System.out.println("Please enter Laptop Id to delete:");
                    int laptopIdToDelete = sc.nextInt();
                    
                    transaction = session.beginTransaction();
                    @SuppressWarnings("rawtypes")
                    Query deleteQuery = session.createQuery("delete from Laptop where lid = :lid");
                    deleteQuery.setParameter("lid", laptopIdToDelete);
                    result = deleteQuery.executeUpdate();
                    if (result > 0) {
                        System.out.println("Laptop with ID " + laptopIdToDelete + " deleted successfully.");
                    } else {
                        System.out.println("No Laptop found with ID " + laptopIdToDelete + ".");
                    }
                    transaction.commit();
                    break;

                case 3:
                    session.close();
                    sessionFactory.close();
                    sc.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }
}