package com.example.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
    Customer findByUsername(String username);
}
