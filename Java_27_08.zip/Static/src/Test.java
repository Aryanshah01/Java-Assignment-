import java.util.Scanner;


public class Test {
	
	public static int add(int ...a) {
		int sum=0;
		for(int i=0; i<a.length; i++) {
			sum+=a[i];
		}
		return sum;
		
	}

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter numbers: ");
		System.out.println(add(sc.nextInt(), sc.nextInt()));
		System.out.println(add(10,20,30,40,50));
	}

}
