interface printable{
	void PrintDetails(String name,  int score);
}

class cktPlayers implements printable{
	@Override
	public void PrintDetails(String name, int score) {
		System.out.println("Name:"+name+" "+ "Runs:"+score);
	}
}

class ftPlayers implements printable{
	@Override
	public void PrintDetails(String name, int score) {
		System.out.println("Name:"+name+" "+"Goals:"+score);
	}	
}


public class Test {

	public static void main(String[] args) {
		
		cktPlayers p1 = new cktPlayers();
		p1.PrintDetails("Aryan", 100);
		
		System.out.println();
		
		ftPlayers p2 = new ftPlayers();
		p2.PrintDetails("Ronaldo", 5);
	}
}
